﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;

namespace WpfApp4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            startclock();

            File.Create(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\file.txt").Close();
            

        }
        private void startclock()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += tickevent;
            timer.Start();
        }
        private void tickevent(object sender, EventArgs e)
        {
            //throw new notImpLementedException
            string strDate = DateTime.Now.ToString(@"hh\:mm");
        }

        public int a = 0;
        public int b = 0;
        public int c = 100;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (cb_v.Text =="Стакан / 0,2мл")
            {
                b = b + 10;
            }
            else if (cb_v.Text == "Бутылка / 0,5мл")
            {
                b = b + 30;
            }
            else if(cb_v.Text == "Большая бутылка / 1л")
            {
                b = b + 50;
            }
            if (cb_v.Text == "0.1км / ~100 шагов")
            {
                b = b + 1;
            }
            else if (cb_v.Text == "0.5км/ ~500 шагов")
            {
                b = b + 5;
            }
            else if (cb_v.Text == "1км / ~1000 шагов")
            {
                b = b + 10;
            }
            a = a + 1;
            
            ch_results.Text += $"Отметка №{a} - Время: {DateTime.Now.ToString(@"HH\:mm")} - {cb_v.Text}";
            ch_results.Text += "\r";
            File.AppendAllText(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\file.txt", $"Отметка №{a} - Время: {DateTime.Now.ToString(@"HH\:mm")} - {cb_v.Text}\r");
            pb.Value = b;
            if (b >= c)
            {
                MessageBox.Show("Норма на сегодня выполнена !");
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            b_check.IsEnabled = true;

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            cb_v.IsEnabled = true;
            if (sys_c.SelectedItem == sys1)
            {
                sp_1.Visibility = Visibility.Visible;
                sp_2.Visibility = Visibility.Visible;
                sp_3.Visibility = Visibility.Visible;
                v1.Visibility = Visibility.Visible;
                v2.Visibility = Visibility.Visible;
                v3.Visibility = Visibility.Visible;
                v4.Visibility = Visibility.Hidden;
                v5.Visibility = Visibility.Hidden;
                v6.Visibility = Visibility.Hidden;

            }
            else if (sys_c.SelectedItem == sys2)
            {
                sp_1.Visibility = Visibility.Visible;
                sp_2.Visibility = Visibility.Visible;
                sp_3.Visibility = Visibility.Visible;
                v1.Visibility = Visibility.Hidden;
                v2.Visibility = Visibility.Hidden;
                v3.Visibility = Visibility.Hidden;
                v4.Visibility = Visibility.Visible;
                v5.Visibility = Visibility.Visible;
                v6.Visibility = Visibility.Visible;
            }
        }

        private void pb_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            
        }

    }
}
